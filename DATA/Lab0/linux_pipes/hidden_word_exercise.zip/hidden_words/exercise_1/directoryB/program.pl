#!/usr/bin/perl

use strict;
use warnings;

my $char = chr(77);
print "\nThe third character is '$char'\.\n\n";
