#!/usr/bin/perl

use strict;
use warnings;

print "\nPlease enter the size of the text file (in bytes): ";
my $size = <STDIN>;
chomp $size;

# interval since file size seems to change depending on which system you are on?
if (($size > 65) & ($size < 75) ) {
    my $char = chr(77);
	print "\nCorrect! The fourth character is $char.\n\n";
}

else {
	print "Sorry, please try again.\n\n";
}
